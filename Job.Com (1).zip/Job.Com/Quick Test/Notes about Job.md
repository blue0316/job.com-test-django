Notes about Job.com example software 

Simple job

Tech Stacks Used
Python API Programming
SQLiteFlow Backend
HTML/CSS + Java 

1. Candidate Input
2. Hiring Manager
3. Job Listings
4. Candidates review page



* Techniques used in this project 
Smart job search algorithm 

The goal is to create a system with smart applications. The system should be able to predict chances of success based on data profiles for both landing an interview and for candidate qualities. 

Candidates page 

Build your resume and enter your qualifications and what you’re looking for. 

Hiring manager

Enter job description and skills and what there is to offer. Enter what are your requirements and personality type. Should using NLP to extract qualities about a person. 

Job listings page

It should show how likely a person is to be a fit for the job then match them to it. 

Candidate review page 

